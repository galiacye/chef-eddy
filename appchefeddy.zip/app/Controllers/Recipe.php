<?php

namespace App\Controllers;

use HTMLPurifier;
use HTMLPurifier_Config;

class Recipe extends BaseController
{
    private $model;

    public function __construct()
    {
        helper('form');

        $this->model = Model('RecipeModel');
    }

    public function showRecipe(int $id)
    {
        $recipe = $this->model->find($id);
        $data = [
            "recipe" => $recipe
        ];
        return view('Recipe/showRecipe', $data);
    }

    public function recipeIndex(): string
    {
        $recipes = $this->model->findAll();
        $data = [
            "recipes" => $recipes
        ];
        return view('Recipe/recipeIndex', $data);
    }

    public function createRecipe()
    {
        if ($this->request->is('post') === false) {
            return view('Recipe/createRecipe');
        } else {
            // L'user_id vient de la session
            $user_id = session()->get('user_id');

            $rules = [
                "titre" => [
                    "label" => "Titre",
                    "rules" => "required|min_length[2]|max_length[50]",
                    "errors" => [
                        "required"   => "Titre requis",
                        "min_length" => "Titre trop court",
                        "max_length" => "Titre trop long",
                    ]
                ],
                "image_url" => [
                    "label" => "Image",
                    "rules" => "permit_empty|is_image[image_url]|max_size[image_url,2048]|mime_in[image_url,image/jpg,image/jpeg,image/png]",
                    "errors" => [
                        "is_image" => "Le fichier doit être une image",
                        "max_size" => "L'image ne doit pas dépasser 2 Mo",
                        "mime_in"  => "Le fichier doit être au format JPG ou PNG"
                    ]
                ],
                "temps_preparation" => [
                    "label" => "Temps de préparation",
                    "rules" => "permit_empty|integer|greater_than_equal_to[1]|less_than_equal_to[2880]",
                    "errors" => [
                        "integer"               => "Le temps de préparation doit être un nombre entier",
                        "greater_than_equal_to" => "Le temps de préparation doit être d'au moins 1 minute",
                        "less_than_equal_to"    => "Le temps de préparation ne peut pas dépasser 2880 minutes (48h)"
                    ]
                ],
                "temps_cuisson" => [
                    "label" => "Temps de cuisson",
                    "rules" => "permit_empty|integer|greater_than_equal_to[1]|less_than_equal_to[2880]",
                    "errors" => [
                        "integer"               => "Le temps de cuisson doit être un nombre entier",
                        "greater_than_equal_to" => "Le temps de cuisson doit être d'au moins 1 minute",
                        "less_than_equal_to"    => "Le temps de cuisson ne peut pas dépasser 2880 minutes (48h)"
                    ]
                ],
                "contenu" => [
                    "label" => "Étapes de la recette",
                    "rules" => "permit_empty|string|max_length[65535]",
                    "errors" => [
                        "string"     => "La recette doit être une chaîne de caractères",
                        "max_length" => "La recette est trop longue"
                    ]
                ],
                "nb_personnes" => [
                    "label" => "Nombre de personnes",
                    "rules" => "required|integer|greater_than_equal_to[1]|less_than_equal_to[1000]",
                    "errors" => [
                        "required"           => "Le nombre de personnes est requis",
                        "integer"            => "Le nombre de personnes doit être un entier",
                        "greater_than_equal_to" => "Le nombre de personnes doit être au moins 1",
                        "less_than_equal_to" => "Le nombre de personnes ne peut pas dépasser 1000"
                    ]
                ],
                "difficulte" => [
                    "label" => "Difficulté",
                    "rules" => "required|in_list[facile,moyen,difficile]",
                    "errors" => [
                        "required" => "La difficulté est requise",
                        "in_list"  => "La difficulté doit être : facile, moyen ou difficile"
                    ]
                ],
            ];
            if (!$this->validate($rules)) {
                return view('Recipe/createRecipe', [
                    'errors' => $this->validator->getErrors()
                ]);
            }
            // Gestion de l'image
            $image = $this->request->getFile('image_url');
            if ($image && $image->isValid() && !$image->hasMoved()) {
                $newName = $image->getRandomName();
                $image->move(WRITEPATH . 'uploads/recipes', $newName);
                $image_path = 'uploads/recipes/' . $newName;
            } else {
                $image_path = null; // ou une image par défaut
            }

            // Purification du HTML de Quill
            $config = HTMLPurifier_Config::createDefault();
            $purifier = new HTMLPurifier($config);
            $contenu = $purifier->purify($this->request->getPost('contenu'));
            $data = [
                'user_id'           => $user_id,
                'titre'             => $this->request->getPost('titre'),
                'image_url'         => $image_path,
                'temps_preparation' => $this->request->getPost('temps_preparation') ?: null,
                'temps_cuisson'     => $this->request->getPost('temps_cuisson') ?: null,
                'contenu'           => $contenu,
                'nb_personnes'      => $this->request->getPost('nb_personnes'),
                'difficulte'        => $this->request->getPost('difficulte'),
                'statut'            => 'pending',
                'nb_vues'           => 0,
            ];
            $this->model->createRecipe($data);
            return redirect()->to('/recipes')->with('success', 'Recette créée avec succès !');
        }
    }
}
