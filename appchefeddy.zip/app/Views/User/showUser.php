<?= $this->extend('layout') ?>

<?= $this->section('custom-css') ?>
<link href="<?= base_url('css/showUser.css') ?>" rel="stylesheet">
<?= $this->endSection() ?>

<?= $this->section('body') ?>

<div class="ban">
        <h2><?= 'Bonjour ' . $user->username . '<br>' ?></h2>
        <img src="<?= base_url($user->avatar_url) ?>" alt="avatar" style="height:320px;width:300px;border:3px solid red;">
</div>
<?= $user->prenom .' '. $user->nom .'<br>'. $user->email ?>

<?= $this->endSection() ?>