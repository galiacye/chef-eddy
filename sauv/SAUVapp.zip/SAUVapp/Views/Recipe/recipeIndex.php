<?= $this->extend('layout') ?>

<?= $this->section('custom-css') ?>
<link href="allRecipes.css" rel="stylesheet">
<?= $this->endSection() ?>

<?= $this->section('body') ?>
<?php foreach($recipes as $recipe): ?>
    <div class="intro">
        <div class="title">
          
            <h1><?= $recipe->titre ?></h1>
            <p>Temps de préparation: <?= $recipe->temps_preparation ?></p>
            <p>Temps de cuisson: <?= $recipe->temps_cuisson ?></p>
        </div>
        <img src="<?= base_url($recipe->image_url) ?>" alt="image recette" class="img">
    </div>
<?php endforeach ?>
<?= $this->endSection()?>


