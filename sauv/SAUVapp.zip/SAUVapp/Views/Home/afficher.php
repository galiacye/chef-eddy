<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>test images</title>
</head>
<body>
    <h1>Salut</h1>
    <p><img src="./img/sansa.jpeg" alt="sansa"></p>
</body>
</html>